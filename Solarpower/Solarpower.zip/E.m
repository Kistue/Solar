function[E] = E(B)
E = 9.87*sind(2*B)  - 7.53*cosd(B) - 1.5*sind(B);
end