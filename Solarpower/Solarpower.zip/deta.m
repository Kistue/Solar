function[deta] = deta(n)
deta = 23.45 * sind(360*(284+n)/365);  % n---所求日期在一年中的日子数


end