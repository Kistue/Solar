function[w] = w(Suntime)
w = 15 * (Suntime - 12);
end